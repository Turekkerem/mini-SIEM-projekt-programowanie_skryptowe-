import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

class Config:
    # Klucz musi być trudny do zgadnięcia (Security Hardening)
    SECRET_KEY = os.getenv('SECRET_KEY', 'bardzo-tajny-klucz-produkcyjny-zmien-mnie')
    
    # Baza danych SQLite
    SQLALCHEMY_DATABASE_URI = os.getenv('SQLALCHEMY_DATABASE_URI', 'sqlite:///../instance/lab7.db')
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Konfiguracja SSH dla Kali Linux (zgodnie z prośbą: bez Vagranta, user kali/kali)
    SSH_DEFAULT_USER = os.getenv('SSH_DEFAULT_USER', 'kali')
    SSH_DEFAULT_PORT = int(os.getenv('SSH_DEFAULT_PORT', 22))
    SSH_PASSWORD = os.getenv('SSH_PASSWORD', 'kali')
    SSH_KEY_FILE = None # Wyłączamy auth kluczem na rzecz hasła

    # Folder na logi (Parquet) - tworzymy go automatycznie jeśli nie istnieje
    STORAGE_FOLDER = Path.cwd() / 'storage'
    os.makedirs(STORAGE_FOLDER, exist_ok=True)